﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameScene
{
    class Scene
    {
        List<GameObject> _objList = new List<GameObject>(32);
        Rendering _rendering = null;

        public double Width { get; set; }
        public double Height { get; set; }

        public Scene()
        {
            Width = 0;
            Height = 0;
            _rendering = new Rendering(this);
        }

        public void AddGameObject(GameObject obj)
        {
            _objList.Add(obj);

            _rendering.DrawEllipse(obj);
        }
    }
}
